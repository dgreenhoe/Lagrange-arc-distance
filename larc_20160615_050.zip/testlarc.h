/*============================================================================
 * Daniel J. Greenhoe
 *============================================================================*/
extern int test_opair(void);
extern int test_vectR2(void);
extern int test_complex(void);
extern int test_seqR2(void);
extern int test_vectR6(void);

int test_otriple(void);
int test_osix(void);



extern int test_pqtheta(void);
extern int test_circle(void);

extern int test_halfcircle(void);
extern int test_circle_d1(void);
extern int test_findt(void);
extern int test_perimeter(void);
extern int test_normalize(void);
extern int test_larc_metric_R2(void);
extern int test_larc_metric_R3(void);
extern int test_larc_metric_R6(void);
extern int test_conj(void);
extern int test_test(void);
extern int test_expi(void);








